package com.example.pedri;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class AvailableListCar extends AppCompatActivity {
    private ListView listViewCars;
    private TextView noCarsTextView;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.available_list_car);

        listViewCars = findViewById(R.id.listViewCars);
        noCarsTextView = findViewById(R.id.noCarsTextView);
        backButton = findViewById(R.id.backButton);

        // Παίρνουμε τα δεδομένα από το Intent
        ArrayList<String> carList = getIntent().getStringArrayListExtra("carList");

        if (carList == null || carList.isEmpty()) {
            // Αν δεν υπάρχουν διαθέσιμα αυτοκίνητα
            noCarsTextView.setVisibility(View.VISIBLE);
        } else {
            // Εμφανίζουμε τα δεδομένα στην ListView
            listViewCars.setVisibility(View.VISIBLE);
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, carList);
            listViewCars.setAdapter(adapter);
        }

        // Ορίζουμε την λειτουργικότητα του κουμπιού backButton
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Επιστρέφουμε στο CarRental activity
                finish();
            }
        });
    }
}
