package com.example.pedri;





import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import  java.sql.Statement;
import java.sql.SQLException;
import java.sql.SQLException.*;


import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import java.sql.*;
import javax.sql.*;
import javax.xml.transform.Result;

public class LogIn extends AppCompatActivity {

    //Orismos URL VASIS.The format of the URL is [protocol]:[subprotocol]:[server:port/databaseName]
    String DB_URL = "jdbc:mysql://localhost:3306/PeDri";
    String name, str;
    ResultSet rs;
    Connection con;
    ConnectionClass connectionClass;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.log_in_menu);

        TextView username = (TextView) findViewById(R.id.username);
        TextView password = (TextView) findViewById(R.id.password);

        MaterialButton loginbtn = (MaterialButton) findViewById(R.id.loginbtn);
        connectionClass = new ConnectionClass();
        connect();



    //admin and admin

        loginbtn.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick (View v){

           login();


/*
                if (username.getText().toString().equals("admin") && password.getText().toString().equals("admin")) {
                    //correct
                    //connectionDatabase=new ConnectionDatabase();
                    //ConnectionDatabase.connect();
                    //Toast.makeText(LogIn.this, "LOGIN SUCCESSFUL", Toast.LENGTH_SHORT).show();
                    //CentralMenuUser i=new CentralMenuUser();

                    Intent intent = new Intent(LogIn.this, CentralMenuUser.class);
                    startActivity(intent);
                    //setContentView(R.layout.central_menu_user);
                } else
                    //incorrect
                    Toast.makeText(LogIn.this, "LOGIN FAILED !!!", Toast.LENGTH_SHORT).show();
*/

        }

        });
    }





    public void connect() {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                con = ConnectionClass.CONN();
                if (con == null)
                    str = "Error in connection in MySQL Server";
                else
                    str = "Connected with MySql Server";
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            runOnUiThread(() -> {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
            });
        });

    }
        public void login() {
            ExecutorService executorService = Executors.newSingleThreadExecutor();
            executorService.execute(() -> {
                try {

                    TextView username = (TextView) findViewById(R.id.username);
                    TextView password = (TextView) findViewById(R.id.password);
                    con = ConnectionClass.CONN();
                    String sql = "SELECT * FROM user where username = '"+username.getText() +
                            "' and password ='" + password.getText() + "'";

                    PreparedStatement stmt = con.prepareStatement(sql);
                    ResultSet rs = stmt.executeQuery(sql);

                    String pass_word = null;
                    String user_name = null;
                    while(rs.next()) {
                        user_name = rs.getString("username");
                        pass_word = rs.getString("password");
                    }
                    String finalUser_name = user_name;
                    String finalPass_word = pass_word;

                    runOnUiThread(() -> {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if ( username.getText().toString().equals(finalUser_name)&&
                                password.getText().toString().equals(finalPass_word)) {
                            Toast.makeText(LogIn.this, "LOGIN SUCCESSFUL", Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(LogIn.this, CentralMenuUser.class);
                            startActivity(intent);

                        }else{
                            Toast.makeText(LogIn.this, "LOGIN FAILED !!!", Toast.LENGTH_SHORT).show();
                        }

                    });
                    con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }


            });


        }

}