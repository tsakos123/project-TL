package com.example.pedri;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import com.google.android.material.button.MaterialButton;
public class CentralMenuUser extends AppCompatActivity {


    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.central_menu_user);

        Button btn=findViewById(R.id.btn_carRental);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(CentralMenuUser.this,CarRental.class);
                startActivity(intent);
            }
        });


    }


    public void btnReservation(View view) {
        Intent intent=new Intent(CentralMenuUser.this,ServicesPage.class);
        startActivity(intent);
    }
}

