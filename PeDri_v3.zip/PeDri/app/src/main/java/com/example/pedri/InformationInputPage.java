package com.example.pedri;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class InformationInputPage extends AppCompatActivity {
    private DatePickerDialog datePickerDialog;
    private Button dateButton;
    private Spinner spinnerLocation, spinnerTimes;
    private EditText lockedEditText;
    private String selectedDate, selectedLocation, selectedTime, userName;
    private Connection con;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.information_input_page);

        userName = getIntent().getStringExtra("username");

        dateButton = findViewById(R.id.datePickerButton);
        spinnerLocation = findViewById(R.id.spinnerLocation);
        spinnerTimes = findViewById(R.id.spinnerTimes);
        lockedEditText = findViewById(R.id.lockedEditText);

        initDatePicker();
        dateButton.setText(getTodaysDate());

        openLocationPicker();
    }

    private String getTodaysDate() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        return makeDateString(day, month, year);
    }

    private void initDatePicker() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        datePickerDialog = new DatePickerDialog(this, AlertDialog.THEME_HOLO_LIGHT, (datePicker, year1, month1, day1) -> {
            month1 = month1 + 1;
            selectedDate = makeDateString(day1, month1, year1);
            dateButton.setText(selectedDate);
            loadAvailableTimes();
        }, year, month, day);
    }

    private String makeDateString(int day, int month, int year) {
        return day + "/" + month + "/" + year;
    }

    public void openDatePicker(View view) {
        datePickerDialog.show();
    }

    private void openLocationPicker() {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                con = ConnectionClass.CONN();
                String sql = "SELECT DISTINCT location_parking FROM Parking";
                PreparedStatement stmt = con.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery();
                ArrayList<String> locations = new ArrayList<>();
                while (rs.next()) {
                    String location = rs.getString("location_parking");
                    locations.add(location);
                }
                runOnUiThread(() -> {
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, locations);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerLocation.setAdapter(adapter);

                    spinnerLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            selectedLocation = parent.getItemAtPosition(position).toString();
                            retrieveCompanyName();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {}
                    });
                });
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private void retrieveCompanyName() {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                con = ConnectionClass.CONN();
                String sql = "SELECT DISTINCT name_parking FROM Parking WHERE location_parking = ?";
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setString(1, selectedLocation);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    String companyName = rs.getString("name_parking");
                    runOnUiThread(() -> lockedEditText.setText(companyName));
                }
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private void loadAvailableTimes() {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                con = ConnectionClass.CONN();
                String sql = "SELECT available_times FROM Parking WHERE location_parking = ? AND date_parking = ? AND month_parking = ? AND year_parking = ?";
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setString(1, selectedLocation);
                String[] dateParts = selectedDate.split("/");
                stmt.setInt(2, Integer.parseInt(dateParts[0]));
                stmt.setString(3, dateParts[1]);
                stmt.setInt(4, Integer.parseInt(dateParts[2]));
                ResultSet rs = stmt.executeQuery();
                ArrayList<String> times = new ArrayList<>();
                if (rs.next()) {
                    String availableTimes = rs.getString("available_times");
                    for (String time : availableTimes.split(",")) {
                        times.add(time);
                    }
                }
                runOnUiThread(() -> {
                    if (times.isEmpty()) {
                        Toast.makeText(this, "Μη διαθέσιμες ώρες για αυτή την ημερομηνία", Toast.LENGTH_SHORT).show();
                        dateButton.setText("Select Date");
                        selectedDate = null;
                    } else {
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, times);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinnerTimes.setAdapter(adapter);
                        spinnerTimes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                selectedTime = parent.getItemAtPosition(position).toString();
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {}
                        });
                    }
                });
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public void searchAvailableTimes(View view) {
        if (selectedDate != null && selectedLocation != null && selectedTime != null) {
            ExecutorService executorService = Executors.newSingleThreadExecutor();
            executorService.execute(() -> {
                try {
                    con = ConnectionClass.CONN();
                    String sql = "SELECT name_parking FROM Parking WHERE location_parking = ? AND date_parking = ? AND month_parking = ? AND year_parking = ? AND available_times LIKE ?";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setString(1, selectedLocation);
                    String[] dateParts = selectedDate.split("/");
                    stmt.setInt(2, Integer.parseInt(dateParts[0]));
                    stmt.setString(3, dateParts[1]);
                    stmt.setInt(4, Integer.parseInt(dateParts[2]));
                    stmt.setString(5, "%" + selectedTime + "%");
                    ResultSet rs = stmt.executeQuery();
                    ArrayList<String> availableParking = new ArrayList<>();
                    while (rs.next()) {
                        String parkingName = rs.getString("name_parking");
                        availableParking.add(parkingName);
                    }
                    con.close();
                    runOnUiThread(() -> {
                        if (!availableParking.isEmpty()) {
                            Intent intent = new Intent(InformationInputPage.this, ListOfBusiness.class);
                            intent.putExtra("username", userName);
                            intent.putExtra("selectedDate", selectedDate);
                            intent.putExtra("selectedLocation ", selectedLocation);
                            intent.putExtra("selectedTime", selectedTime);
                            startActivity(intent);
                        } else {
                            Toast.makeText(this, "Δεν υπάρχουν διαθέσιμα Parking για τη συγκεκριμένη ώρα", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        } else {
            Toast.makeText(this, "Παρακαλώ επιλέξτε ημερομηνία, τοποθεσία και ώρα", Toast.LENGTH_SHORT).show();
        }
    }


    public void InsertInfo(View view) {
        if (selectedDate != null && selectedLocation != null && selectedTime != null) {
            ExecutorService executorService = Executors.newSingleThreadExecutor();
            executorService.execute(() -> {
                try {
                    con = ConnectionClass.CONN();
                    String sql = "INSERT INTO ParkingReservation (username, location_parking, date_parking, month_parking, year_parking, time_parking) VALUES (?, ?, ?, ?, ?, ?)";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setString(1, userName);
                    stmt.setString(2, selectedLocation);
                    String[] dateParts = selectedDate.split("/");
                    stmt.setInt(3, Integer.parseInt(dateParts[0]));
                    stmt.setString(4, dateParts[1]);
                    stmt.setInt(5, Integer.parseInt(dateParts[2]));
                    stmt.setString(6, selectedTime);
                    stmt.executeUpdate();
                    con.close();
                    runOnUiThread(() -> {
                        Toast.makeText(this, "Η κράτηση πραγματοποιήθηκε με επιτυχία", Toast.LENGTH_SHORT).show();
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        } else {
            Toast.makeText(this, "Παρακαλώ επιλέξτε ημερομηνία, τοποθεσία και ώρα", Toast.LENGTH_SHORT).show();
        }
    }

    public void ButtonBack(View view) {
        Intent intent = new Intent(InformationInputPage.this, ServicesPage.class);
        intent.putExtra("username", userName);
        intent.putExtra("selectedDate", selectedDate);
        intent.putExtra("selectedLocation", selectedLocation);
        startActivity(intent);
    }
}
