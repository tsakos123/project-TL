package com.example.pedri;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class CentralMenuOwner extends AppCompatActivity {

    private String userNameOwner, userName;
    private Button btnRequestReservation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.central_menu_owner);

        btnRequestReservation = findViewById(R.id.btnRequestReservation);

        // Λήψη παραμέτρων από το Intent
        userNameOwner = getIntent().getStringExtra("username_owner");

        // Κλήση για λήψη του αριθμού αιτημάτων
        new FetchReservationRequestsTask().execute();

        Intent intent = new Intent(CentralMenuOwner.this, Profile.class);
        intent.putExtra("username_owner", userNameOwner);
    }

    public void btnPriceUpdate(View view) {
    }

    public void btnRequestReservation(View view) {
        Intent intent = new Intent(CentralMenuOwner.this, ReservationRequests.class);
        startActivity(intent);
    }

    public void btn_Profil(View view) {
        Intent intent = new Intent(CentralMenuOwner.this, Profile.class);
        intent.putExtra("username_owner", userNameOwner);
        startActivity(intent);
    }

    public void chooseWallet(View view) {
        show_wp();
    }
    public void show_wp(){
        Intent intent=new Intent(CentralMenuOwner.this,WalletProfile.class);
        intent.putExtra("username_owner",userNameOwner);
        startActivity(intent);
    }

    private class FetchReservationRequestsTask extends AsyncTask<Void, Void, Integer> {
        @Override
        protected Integer doInBackground(Void... voids) {
            int count = 0;
            try {
                Connection con = ConnectionClass.CONN();
                if (con != null) {
                    String query = "SELECT COUNT(*) AS count FROM requestReservation WHERE owner_id = ?";
                    PreparedStatement stmt = con.prepareStatement(query);
                    stmt.setString(1, userNameOwner);
                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        count = rs.getInt("count");
                    }
                    rs.close();
                    stmt.close();
                    con.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return count;
        }

        @Override
        protected void onPostExecute(Integer count) {
            if (count > 0) {
                btnRequestReservation.setText("Αιτήματα Κρατήσεων (" + count + ")");
            } else {
                btnRequestReservation.setText("Αιτήματα Κρατήσεων");
            }
        }
    }
}
