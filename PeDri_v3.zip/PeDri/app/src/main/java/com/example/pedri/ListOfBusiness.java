package com.example.pedri;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.pedri.ConnectionClass;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ListOfBusiness extends AppCompatActivity {
    private ListView listViewBusiness;
    private String selectedDate, selectedLocation, selectedTime, userName;
    private Connection con;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_of_bussiness);

        selectedDate = getIntent().getStringExtra("selectedDate");
        selectedLocation = getIntent().getStringExtra("selectedLocation");
        selectedTime = getIntent().getStringExtra("selectedTime");
        userName = getIntent().getStringExtra("username");

        listViewBusiness = findViewById(R.id.listViewBusiness);

        loadAvailableParking();
    }

    private void loadAvailableParking() {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                con = ConnectionClass.CONN();
                String sql = "SELECT name_parking FROM Parking WHERE location_parking = ? AND available_times LIKE ?";
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setString(1, selectedLocation);
                stmt.setString(2, "%" + selectedTime + "%");
                ResultSet rs = stmt.executeQuery();
                ArrayList<String> availableParking = new ArrayList<>();
                while (rs.next()) {
                    String parkingName = rs.getString("name_parking");
                    if (!isParkingReserved(parkingName, selectedDate, selectedTime)) {
                        availableParking.add(parkingName);
                    }
                }
                con.close();
                runOnUiThread(() -> {
                    if (!availableParking.isEmpty()) {
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, availableParking);
                        listViewBusiness.setAdapter(adapter);
                    } else {
                        Toast.makeText(this, "Δεν υπάρχουν διαθέσιμα Parking για τη συγκεκριμένη ώρα", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private boolean isParkingReserved(String parkingName, String date, String time) {
        try {
            con = ConnectionClass.CONN();
            String sql = "SELECT * FROM ParkingReservation WHERE location_parking = ? AND date_parking = ? AND month_parking = ? AND year_parking = ? AND time_parking = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, selectedLocation);
            String[] dateParts = selectedDate.split("/");
            stmt.setInt(2, Integer.parseInt(dateParts[0]));
            stmt.setString(3, dateParts[1]);
            stmt.setInt(4, Integer.parseInt(dateParts[2]));
            stmt.setString(5, selectedTime);
            ResultSet rs = stmt.executeQuery();
            boolean isReserved = rs.next();
            con.close();
            return isReserved;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
