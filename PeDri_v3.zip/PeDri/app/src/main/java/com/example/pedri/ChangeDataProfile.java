package com.example.pedri;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ChangeDataProfile extends AppCompatActivity {
    private EditText nameEditText, contactEditText, addressEditText, idEditText;
    private Button SaveInfo;
    private String userName,userNameOwner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.change_data_profile);

        nameEditText = findViewById(R.id.nameEditText);
        contactEditText = findViewById(R.id.contactEditText);
        addressEditText = findViewById(R.id.addressEditText);
        idEditText = findViewById(R.id.idEditText);
        SaveInfo = findViewById(R.id.SaveInfo);

        userName = getIntent().getStringExtra("username");
        userNameOwner = getIntent().getStringExtra("username_owner");

        // Λήψη των δεδομένων από το Intent
        if (userName!=null) {
            //Για τον Χρήστη
            //userName = getIntent().getStringExtra("username");
            nameEditText.setText(getIntent().getStringExtra("name"));
            contactEditText.setText(getIntent().getStringExtra("contact"));
            addressEditText.setText(getIntent().getStringExtra("address"));
            idEditText.setText(getIntent().getStringExtra("identity"));
        } else if (userNameOwner!=null) {
            //Για τον Ιδιοκτήτη
            //userNameOwner = getIntent().getStringExtra("username_owner");
            nameEditText.setText(getIntent().getStringExtra("name"));
            contactEditText.setText(getIntent().getStringExtra("contact"));
            addressEditText.setText(getIntent().getStringExtra("address"));
            idEditText.setText(getIntent().getStringExtra("identity"));
        }

        SaveInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAndProceed();
            }
        });
    }

    private void checkAndProceed() {
        if (userName!=null) {
            //Για τον Χρήστη
            String name = nameEditText.getText().toString().trim();
            String contact = contactEditText.getText().toString().trim();
            String address = addressEditText.getText().toString().trim();
            String id = idEditText.getText().toString().trim();

            if (name.isEmpty() || contact.isEmpty() || address.isEmpty() || id.isEmpty()) {
                Toast.makeText(this, "Παρακαλώ συμπληρώστε όλα τα πεδία", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(ChangeDataProfile.this, VerificationPage.class);
                intent.putExtra("username", userName);
                intent.putExtra("name", name);
                intent.putExtra("contact", contact);
                intent.putExtra("address", address);
                intent.putExtra("identity", id);
                startActivity(intent);
            }
        } else if (userNameOwner!=null) {
            //Για τον Ιδιοκτήτη
            String name = nameEditText.getText().toString().trim();
            String contact = contactEditText.getText().toString().trim();
            String address = addressEditText.getText().toString().trim();
            String id = idEditText.getText().toString().trim();

            if (name.isEmpty() || contact.isEmpty() || address.isEmpty() || id.isEmpty()) {
                Toast.makeText(this, "Παρακαλώ συμπληρώστε όλα τα πεδία", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(ChangeDataProfile.this, VerificationPage.class);
                intent.putExtra("username_owner", userNameOwner);
                intent.putExtra("name", name);
                intent.putExtra("contact", contact);
                intent.putExtra("address", address);
                intent.putExtra("identity", id);
                startActivity(intent);
            }
        }
    }

}
