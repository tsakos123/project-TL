package com.example.pedri;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.PreparedStatement;


public class PreviewScreenForm extends AppCompatActivity {

    private String startLocation;
    private String endLocation;
    private String date;
    private String time;
    private String tripCost;
    private String carName;
    private String maxPassengers;
    private String hasTraveledBefore;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.preview_screen_form);

        Intent intent = getIntent();
        startLocation = intent.getStringExtra("startLocation");
        endLocation = intent.getStringExtra("endLocation");
        date = intent.getStringExtra("date");
        time = intent.getStringExtra("time");
        tripCost = intent.getStringExtra("tripCost");
        carName = intent.getStringExtra("carName");
        maxPassengers = intent.getStringExtra("maxPassengers");
        hasTraveledBefore = intent.getStringExtra("hasTraveledBefore");

        TextView startLocationTextView = findViewById(R.id.startLocationTextView);
        TextView endLocationTextView = findViewById(R.id.endLocationTextView);
        TextView dateTextView = findViewById(R.id.dateTextView);
        TextView timeTextView = findViewById(R.id.timeTextView);
        TextView tripCostTextView = findViewById(R.id.tripCostTextView);
        TextView carNameTextView = findViewById(R.id.carNameTextView);
        TextView maxPassengersTextView = findViewById(R.id.maxPassengersTextView);
        TextView hasTraveledBeforeTextView = findViewById(R.id.hasTraveledBeforeTextView);

        startLocationTextView.setText(startLocation);
        endLocationTextView.setText(endLocation);
        dateTextView.setText(date);
        timeTextView.setText(time);
        tripCostTextView.setText(tripCost);
        carNameTextView.setText(carName);
        maxPassengersTextView.setText(maxPassengers);
        hasTraveledBeforeTextView.setText(hasTraveledBefore);

        Button submitButton = findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showConfirmationDialog();
            }
        });

    }

    private void showConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Επιβεβαίωση Δημοσίευσης");
        builder.setMessage("Είστε σίγουρος ότι θέλετε να δημοσιεύσετε τη διαδρομή;");
        builder.setPositiveButton("Ναι", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Κώδικας για τη δημοσίευση της διαδρομής
                submitRoute();
            }
        });
        builder.setNegativeButton("Όχι", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @SuppressLint("StaticFieldLeak")
    private void submitRoute() {
        // Εκτέλεση ασύγχρονης εργασίας για διαγραφή και εισαγωγή δεδομένων
        new AsyncTask<Void, Void, Boolean>() {
            @Override
            protected Boolean doInBackground(Void... voids) {
                boolean success = false;
                try {
                    Connection con = ConnectionClass.CONN();
                    // SQL εντολή για διαγραφή από τον πίνακα CarPoolDriverRequest
                    String deleteSql = "DELETE FROM CarPoolDriverRequest WHERE address_departure_point = ? AND endpoint_address = ? AND date = ? AND start_time = ?";
                    PreparedStatement deleteStmt = con.prepareStatement(deleteSql);
                    deleteStmt.setString(1, startLocation);
                    deleteStmt.setString(2, endLocation);
                    deleteStmt.setString(3, date);
                    deleteStmt.setString(4, time);
                    deleteStmt.executeUpdate();

                    // SQL εντολή για εισαγωγή στον πίνακα RoutesPosts
                    String insertSql = "INSERT INTO RoutesPosts (address_departure_point, endpoint_address, date, start_time ,max_number_passenger ,cost_route ,route_again ,car_name_dr) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement insertStmt = con.prepareStatement(insertSql);
                    insertStmt.setString(1, startLocation);
                    insertStmt.setString(2, endLocation);
                    insertStmt.setString(3, date);
                    insertStmt.setString(4, time);
                    insertStmt.setString(5, maxPassengers);
                    insertStmt.setString(6, tripCost);
                    insertStmt.setString(7, hasTraveledBefore);
                    insertStmt.setString(8, carName);
                    insertStmt.executeUpdate();

                    con.close();
                    success = true;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return success;
            }

            @Override
            protected void onPostExecute(Boolean success) {
                if (success) {
                    new AlertDialog.Builder(PreviewScreenForm.this)
                            .setTitle("Επιτυχία")
                            .setMessage("Η διαδρομή δημοσιεύτηκε επιτυχώς.")
                            .setPositiveButton(android.R.string.ok, null)
                            .show();
                } else {
                    new AlertDialog.Builder(PreviewScreenForm.this)
                            .setTitle("Σφάλμα")
                            .setMessage("Η δημοσίευση της διαδρομής απέτυχε.")
                            .setPositiveButton(android.R.string.ok, null)
                            .show();
                }
            }
        }.execute();
    }


    public void ButtonBack(View view) {
        Intent intent = new Intent(PreviewScreenForm.this, FormNewRouteDriver.class);
        startActivity(intent);
    }

}

