package com.example.pedri;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ServicesPage extends AppCompatActivity {

    private Button backButton;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.service_page);
        backButton = findViewById(R.id.backButton);
        // Ορίζουμε την λειτουργικότητα του κουμπιού backButton
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Επιστρέφουμε στο CarRental activity
                finish();
            }
        });
    }
    
}
