package com.example.pedri;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import com.google.android.material.button.MaterialButton;

import java.sql.Connection;

public class CentralMenuOwner extends AppCompatActivity {

    private String userNameOwner,userName;

    protected void onCreate (Bundle savedInstanceState) {
        Connection con = ConnectionClass.CONN();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.central_menu_owner);

        Intent intent = new Intent(CentralMenuOwner.this, LockedProfile.class);
        intent.putExtra("username_owner", userNameOwner);

        String name = getIntent().getStringExtra("name");
        String contact = getIntent().getStringExtra("contact");
        String address = getIntent().getStringExtra("address");
        String id = getIntent().getStringExtra("id");
        userNameOwner = getIntent().getStringExtra("username_owner");

    }


    public void btnPriceUpdate(View view) {
    }

    public void btnRequestReservation(View view) {
        Intent intent = new Intent(CentralMenuOwner.this, ReservationRequests.class);
        startActivity(intent);
    }


    public void btn_Profil(View view) {
        //String userNameOwner = getIntent().getStringExtra("username_owner");
        Intent intent = new Intent(CentralMenuOwner.this, LockedProfile.class);
        intent.putExtra("username_owner", userNameOwner);
        startActivity(intent);
    }


}

