package com.example.pedri;

import androidx.appcompat.app.AppCompatActivity;

public class Payment extends AppCompatActivity {

}
