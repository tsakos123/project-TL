package com.example.pedri;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class WalletProfile extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wallet_profile);
    }

}
