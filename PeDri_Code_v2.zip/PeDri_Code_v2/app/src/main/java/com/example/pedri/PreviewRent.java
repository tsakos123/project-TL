package com.example.pedri;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PreviewRent extends AppCompatActivity {
    private TextView companyNameTextView, phoneTextView, carTextView, costTextView, durationTextView;
    private String userName,companyName,carName,duration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.preview_rent);

        companyNameTextView = findViewById(R.id.companyNameTextView);
        phoneTextView = findViewById(R.id.phoneTextView);
        carTextView = findViewById(R.id.carTextView);
        costTextView = findViewById(R.id.costTextView);
        durationTextView = findViewById(R.id.durationTextView);

        // Λήψη των στοιχείων από το Intent
        Intent intent = getIntent();


        carName=intent.getStringExtra("carName");
        duration=intent.getStringExtra("duration_rent");
        companyName=intent.getStringExtra("cars_rental_company");
        userName = intent.getStringExtra("username");

        fetchData();
    }

    private void fetchData() {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                Connection con = ConnectionClass.CONN();
                String sql = "SELECT c.cars_rental_company, c.phone_number, c.name_car, c.car_cost_per_day, p.duration_rent " +
                        "FROM cars c, PickUpVehicle p " +
                        "WHERE c.name_car = ? AND p.duration_rent = ? " +
                        "LIMIT 1";
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setString(1, carName);
                stmt.setString(2, duration);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    String companyName = rs.getString("cars_rental_company");
                    String phone = rs.getString("phone_number");
                    String carName = rs.getString("name_car");
                    double costPerDay = rs.getDouble("car_cost_per_day");
                    int duration = rs.getInt("duration_rent");

                    double totalCost = costPerDay * duration;

                    runOnUiThread(() -> {
                        companyNameTextView.setText(companyName);
                        phoneTextView.setText(phone);
                        carTextView.setText(carName);
                        costTextView.setText(String.format("%.2f €", totalCost));
                        durationTextView.setText(String.valueOf(duration) + " ημέρες");
                    });
                }
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public void ButtonBack(View view) {
        Intent intent=new Intent(PreviewRent.this,DriverPersonalFormCarRent.class);
        intent.putExtra("username",userName);
        startActivity(intent);
    }

    public void paymentButton(View view) {
    }
}
